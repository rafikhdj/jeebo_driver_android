package com.app.utils;

/**
 * Class is used to define constant items
 */

public class AppConstant {
    public static final String DEVICE_OS = "";

    public class PrefsName {

        public static final String USERNAME = "username";
    }

    public interface INTENT_EXTRAS {
        String SMS_RECEIVED = "sms_received";
    }
}
